/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

/**
 * Esta classe serve para iniciar uma nova conexão com o banco de dados SQL usando as credenciais do projeto.
 * 
 * Ela é ABSTRACT porque será herdada pelas demais classes do pacote modelos.
 * @author cadud
 */
public abstract class ConexaoDataBase {
    
    
}
